// Modified portion of Hobby_Quiz.ts focusing on quiz layout fixes

document.addEventListener("DOMContentLoaded", () => {
  // Sound effects
  const clickSfx = new Audio('../static/sounds/ding1.mp3');
  const ding2Sfx = new Audio('../static/sounds/ding2.mp3');
  clickSfx.preload = 'auto';
  clickSfx.load();
  ding2Sfx.preload = 'auto';
  ding2Sfx.load();
  ding2Sfx.volume = clickSfx.volume;
  clickSfx.volume = 0.6;

  // Progress bar setup
  const progressBarContainer = document.createElement("div");
  progressBarContainer.className = "progress-bar-container";
  const progressBarFill = document.createElement("div");
  progressBarFill.className = "progress-bar-fill";
  progressBarFill.style.width = "0%";
  progressBarContainer.appendChild(progressBarFill);

  const progressText = document.createElement("div");
  progressText.className = "progress-bar-text";
  progressText.textContent = "0 / X";
  progressBarContainer.appendChild(progressText);

  // Navigation buttons
  const navDiv = document.createElement("div");
  navDiv.className = "nav-buttons";
  const backBtn = document.createElement("button");
  backBtn.innerHTML = "&#8592;";
  backBtn.disabled = true;
  const nextBtn = document.createElement("button");
  nextBtn.innerHTML = "&#8594;";
  navDiv.append(backBtn, nextBtn);

  // Append both inside quiz-card
  const quizCard = document.querySelector(".quiz-card") as HTMLElement;
  quizCard?.appendChild(progressBarContainer);
  quizCard?.appendChild(navDiv);

  // Removed window.addEventListener('resize', ...) block to stop overriding layout

  // The rest of your logic continues unchanged...
});